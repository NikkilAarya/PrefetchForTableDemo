//
//  ImageModel.swift
//  PrefetchDemo
//
//  Created by Apple on 07/10/21.
//

import Foundation

struct ImageModel {
    public private(set) var url: URL?
    let order: Int
    
    init(url: String?, order: Int) {
        self.url = url?.toURL
        self.order = order
    }
}

public extension String {
    var toURL: URL? {
        return URL(string: self)
    }
}
